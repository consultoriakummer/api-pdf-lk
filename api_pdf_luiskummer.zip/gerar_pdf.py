#!/usr/bin/env python3
import math, datetime
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, black

BG=HexColor('#FAF7F2'); SURFACE=HexColor('#F2EDE4'); CARD=HexColor('#EDE8DF')
BORDER=HexColor('#D8CEBF'); ACCENT=HexColor('#2D5016'); ACCENT2=HexColor('#4A7C2F')
GOLD=HexColor('#C8A84B'); DARK=HexColor('#1A1A1A'); MID=HexColor('#5A5A5A')
MUTED=HexColor('#9A9A9A'); ORANGE=HexColor('#C4622D'); BLUE_EL=HexColor('#2B5278')
RED_EL=HexColor('#8B2020'); WHITE=HexColor('#FFFFFF')
W,H=390,844
LINKS={119:"https://pages.mfitpersonal.com.br/index?acao=page&tipo=2&buyPage=112636&page=112636",
       207:"https://pages.mfitpersonal.com.br/index?acao=page&tipo=2&buyPage=112637&page=112636",
       297:"https://pages.mfitpersonal.com.br/index?acao=page&tipo=2&buyPage=112638&page=112636",
       479:"https://pages.mfitpersonal.com.br/index?acao=page&tipo=2&buyPage=112639&page=112636"}

def calc_imc(p,a):
    try: return round(float(p)/(float(a)/100)**2,1)
    except: return None

def imc_info(imc):
    if imc is None: return "—",MUTED,0.5
    if imc<18.5: return "Abaixo do peso",BLUE_EL,max(0,(imc-14)/26)
    if imc<25: return "Peso normal",ACCENT2,(imc-14)/26
    if imc<30: return "Sobrepeso",ORANGE,(imc-14)/26
    return "Obesidade",RED_EL,min(1,(imc-14)/26)

def calc_tmb(p,a,i,s):
    try:
        p,a,i=float(p),float(a),float(i)
        return round(88.36+13.4*p+4.8*a-5.7*i) if 'M' in str(s).upper() else round(447.6+9.2*p+3.1*a-4.3*i)
    except: return None

def calc_kcal(tmb,obj):
    if not tmb: return None
    if any(x in str(obj).lower() for x in ['emagre','perder']): return tmb-400
    if any(x in str(obj).lower() for x in ['massa','ganhar']): return tmb+300
    return tmb

def meses(p,po):
    try:
        d=abs(float(p)-float(po)); m=math.ceil(d/4)
        return f"{m} a {m+1} meses"
    except: return "3 a 5 meses"

def pct_gord(imc,s):
    try:
        i=float(imc)
        v=(1.20*i)+(0.23*30)-(16.2 if 'M' in str(s).upper() else 5.4)
        return round(max(5,min(50,v)),1)
    except: return None

def rr(c,x,y,w,h,r=6,fill=None,stroke=None,lw=0.5):
    c.saveState()
    if fill: c.setFillColor(fill)
    if stroke: c.setStrokeColor(stroke); c.setLineWidth(lw)
    p=c.beginPath(); p.roundRect(x,y,w,h,r)
    c.drawPath(p,fill=1 if fill else 0,stroke=1 if stroke else 0)
    c.restoreState()

def dbg(c): c.setFillColor(BG); c.rect(0,0,W,H,fill=1,stroke=0)

def hdr(c,n,t=5):
    rr(c,0,H-32,W,32,0,fill=SURFACE)
    c.setStrokeColor(BORDER); c.setLineWidth(0.5); c.line(0,H-32,W,H-32)
    c.setFillColor(ACCENT); c.setFont("Helvetica-Bold",7); c.drawString(16,H-20,"LUIS KUMMER PERSONAL")
    c.setFillColor(MUTED); c.drawRightString(W-16,H-20,f"{n} / {t}")

def ftr(c):
    c.setStrokeColor(BORDER); c.setLineWidth(0.3); c.line(16,26,W-16,26)
    c.setFillColor(MUTED); c.setFont("Helvetica",6.5)
    c.drawCentredString(W/2,14,"@luis_kummer_  ·  Luis Kummer Personal Trainer")

def badge(c,y,txt):
    tw=c.stringWidth(txt,"Helvetica-Bold",7)+16
    rr(c,16,y,tw,18,4,fill=ACCENT)
    c.setFillColor(WHITE); c.setFont("Helvetica-Bold",7); c.drawString(24,y+5,txt)
    return y-26

def title(c,y,txt,sz=22):
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",sz); c.drawString(16,y,txt)
    return y-sz-4

def sub(c,y,txt):
    c.setFillColor(MID); c.setFont("Helvetica",9); c.drawString(16,y,txt)
    return y-16

def wrap(c,txt,font,sz,maxw):
    words=txt.split(); line=[]; lines=[]
    for w in words:
        line.append(w)
        if c.stringWidth(' '.join(line),font,sz)>maxw:
            lines.append(' '.join(line[:-1])); line=[w]
    lines.append(' '.join(line))
    return lines

# CAPA
def capa(c,d):
    dbg(c)
    nome=d.get('nome','').upper() or 'VOCÊ'
    peso=d.get('peso',''); po=d.get('peso_obj','')
    obj=d.get('objetivo',''); dt=d.get('data',datetime.date.today().strftime('%d/%m/%Y'))
    rr(c,0,H-56,W,56,0,fill=ACCENT)
    c.setFillColor(WHITE); c.setFont("Helvetica-Bold",8)
    c.drawCentredString(W/2,H-22,"DIAGNÓSTICO INICIAL PERSONALIZADO")
    c.setFillColor(GOLD); c.setFont("Helvetica",7)
    c.drawCentredString(W/2,H-38,f"Criado exclusivamente para você  ·  {dt}")
    c.setStrokeColor(GOLD); c.setLineWidth(0.5); c.line(30,H-60,W-30,H-60)
    y=H-100
    fs=min(64,max(32,int(280/max(len(nome),1)*1.5)))
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",fs); c.drawCentredString(W/2,y,nome); y-=fs+8
    c.setStrokeColor(GOLD); c.setLineWidth(1); c.line(W/2-60,y,W/2+60,y); y-=18
    if obj:
        c.setFillColor(ACCENT); c.setFont("Helvetica-Bold",13); c.drawCentredString(W/2,y,obj.capitalize()); y-=20
    c.setFillColor(MID); c.setFont("Helvetica",9); c.drawCentredString(W/2,y,"Baseado nas suas respostas ao questionário"); y-=36
    if peso and po:
        try:
            diff=abs(float(peso)-float(po)); acao="Perder" if float(peso)>float(po) else "Ganhar"
            diff_txt=f"{acao} {diff:.0f} kg"
        except: diff_txt="—"
    else: diff_txt="—"
    cols=[(peso+"kg" if peso else "—","Peso atual"),(po+"kg" if po else "—","Peso meta"),(meses(peso,po) if peso and po else "—","Estimativa")]
    cw=(W-48)/3
    for i,(val,lbl) in enumerate(cols):
        cx=16+(cw+8)*i
        rr(c,cx,y-64,cw,64,8,fill=SURFACE,stroke=BORDER)
        rr(c,cx,y-64+61,cw,3,1,fill=ACCENT)
        c.setFillColor(DARK); c.setFont("Helvetica-Bold",15 if len(val)<7 else 12); c.drawCentredString(cx+cw/2,y-34,val)
        c.setFillColor(MUTED); c.setFont("Helvetica",7); c.drawCentredString(cx+cw/2,y-52,lbl)
    y-=80
    c.setStrokeColor(BORDER); c.setLineWidth(0.3); c.line(40,y,W-40,y); y-=22
    c.setFillColor(ACCENT); c.setFont("Helvetica-Bold",9); c.drawCentredString(W/2,y,"O QUE VOCÊ VAI RECEBER"); y-=16
    for item in ["Análise biométrica completa (IMC, gordura, metabolismo)","Projeção personalizada da sua meta","Leitura do seu perfil e obstáculos","Plano de ação e opções de consultoria"]:
        c.setFillColor(ACCENT2); c.setFont("Helvetica-Bold",9); c.drawString(26,y,"▸")
        c.setFillColor(DARK); c.setFont("Helvetica",9); c.drawString(38,y,item); y-=15
    c.setStrokeColor(GOLD); c.setLineWidth(0.5); c.line(30,y,W-30,y)
    c.setFillColor(MUTED); c.setFont("Helvetica",7); c.drawCentredString(W/2,20,"Documento confidencial · Luis Kummer Personal Trainer")

# PG2 BIOMETRICO
def biometrico(c,d):
    dbg(c); hdr(c,1)
    peso=d.get('peso',''); alt=d.get('altura',''); idade=d.get('idade',''); sexo=d.get('sexo','F')
    po=d.get('peso_obj',''); ca=d.get('corpo_atual',''); co=d.get('corpo_obj','')
    bem=d.get('bemestar',''); est=d.get('estresse','')
    imc=calc_imc(peso,alt); tmb=calc_tmb(peso,alt,idade,sexo)
    kcal=calc_kcal(tmb,d.get('objetivo',''))
    pg=pct_gord(imc,sexo); ilbl,icor,ipct=imc_info(imc)
    y=H-50; y=badge(c,y,"SEÇÃO 1  ·  ANÁLISE BIOMÉTRICA"); y=title(c,y,"Seus dados corporais"); y=sub(c,y,"Calculado com base nas suas respostas"); y-=8
    mc=[(f"{peso}kg","Peso atual",ACCENT),(f"{alt}cm","Altura",ACCENT2),(f"{idade}a","Idade",BLUE_EL),(f"{tmb} kcal" if tmb else "—","Metabolismo",ORANGE)]
    cw=(W-40)/2; ch=54
    for i,(val,lbl,ac) in enumerate(mc):
        cx=16+(cw+8)*(i%2); cy=y-ch-(i//2)*(ch+8)
        rr(c,cx,cy,cw,ch,6,fill=SURFACE,stroke=BORDER)
        rr(c,cx,cy+ch-3,cw,3,1,fill=ac)
        c.setFillColor(DARK); c.setFont("Helvetica-Bold",15 if len(val)<7 else 12); c.drawCentredString(cx+cw/2,cy+ch-26,val)
        c.setFillColor(MUTED); c.setFont("Helvetica-Bold",6.5); c.drawCentredString(cx+cw/2,cy+8,lbl.upper())
    y-=(ch+8)*2+10
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",8); c.drawString(16,y,"ÍNDICE DE MASSA CORPORAL (IMC)"); y-=14
    bw=W-32; bh=12
    segs=[(BLUE_EL,.22),(ACCENT2,.28),(ORANGE,.25),(RED_EL,.25)]; sx=16
    for cor,frac in segs:
        c.setFillColor(cor); c.rect(sx,y-bh,bw*frac,bh,fill=1,stroke=0); sx+=bw*frac
    px=16+bw*ipct; c.setFillColor(DARK); c.circle(px,y-bh/2,7,fill=1,stroke=0)
    c.setFillColor(BG); c.circle(px,y-bh/2,4,fill=1,stroke=0)
    c.setFont("Helvetica",6.5); c.setFillColor(MID)
    for lbl,frac in [("Baixo",.11),("Normal",.36),("Sobrepeso",.61),("Obeso",.85)]:
        c.drawCentredString(16+bw*frac,y-bh-9,lbl)
    y-=bh+22
    rr(c,16,y-36,W-32,36,6,fill=SURFACE,stroke=BORDER)
    c.setFillColor(icor); c.setFont("Helvetica-Bold",20); c.drawString(26,y-24,f"IMC  {imc}" if imc else "IMC  —")
    c.setFont("Helvetica-Bold",10); c.drawRightString(W-26,y-18,ilbl)
    c.setFillColor(MUTED); c.setFont("Helvetica",7.5); c.drawRightString(W-26,y-30,"Ideal: 18,5 a 24,9"); y-=46
    extras=[(f"{pg}%" if pg else "—","Gordura corporal estimada",icor),(f"{kcal} kcal/dia" if kcal else "—","Calorias p/ objetivo",ACCENT2),(ca.capitalize() if ca else "—","Perfil corporal atual",MID),(co.capitalize() if co else "—","Perfil corporal objetivo",ACCENT)]
    for val,lbl,cor in extras:
        rr(c,16,y-28,W-32,28,4,fill=SURFACE,stroke=BORDER)
        c.setFillColor(MID); c.setFont("Helvetica",8.5); c.drawString(26,y-18,lbl)
        c.setFillColor(cor); c.setFont("Helvetica-Bold",9); c.drawRightString(W-26,y-18,val); y-=34
    y-=4; hw=(W-40)/2
    for i,(lbl,val,cor) in enumerate([(f"Bem-estar com o corpo",f"{bem}/10",ACCENT2 if int(bem or 0)>=6 else ORANGE),(f"Nível de estresse",f"{est}/10",RED_EL if int(est or 0)>=7 else ACCENT2)]):
        cx=16+(hw+8)*i; rr(c,cx,y-38,hw,38,6,fill=SURFACE,stroke=BORDER)
        c.setFillColor(MID); c.setFont("Helvetica",7.5); c.drawCentredString(cx+hw/2,y-14,lbl)
        c.setFillColor(cor); c.setFont("Helvetica-Bold",16); c.drawCentredString(cx+hw/2,y-32,val)
    ftr(c)

# PG3 META
def meta(c,d):
    dbg(c); hdr(c,2)
    peso=d.get('peso',''); po=d.get('peso_obj',''); comp=d.get('compro','')
    ex=d.get('exercicio',''); tt=d.get('tempo_treino',''); card=d.get('cardio','')
    tc=d.get('tempo_cardio',''); alim=d.get('alimentacao',''); partes=d.get('partes','')
    lim=d.get('limitacao',''); med=d.get('medicamentos','')
    y=H-50; y=badge(c,y,"SEÇÃO 2  ·  META E PERFIL DE HÁBITOS"); y=title(c,y,"Onde você está e onde quer ir"); y-=8
    if peso and po:
        try:
            diff=abs(float(peso)-float(po)); acao="Perder" if float(peso)>float(po) else "Ganhar"; diff_txt=f"{acao} {diff:.0f} kg"
        except: diff_txt="—"
    else: diff_txt="—"
    rr(c,16,y-62,W-32,62,8,fill=SURFACE,stroke=BORDER); rr(c,16,y-62+59,W-32,3,1,fill=ACCENT)
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",22); c.drawString(26,y-32,f"{peso}kg")
    c.setFillColor(ACCENT); c.setFont("Helvetica-Bold",22); c.drawRightString(W-26,y-32,f"{po}kg" if po else "—")
    c.setFillColor(ACCENT2); c.setFont("Helvetica-Bold",10); c.drawCentredString(W/2,y-32,f"→  {diff_txt}  →")
    c.setFillColor(MUTED); c.setFont("Helvetica",7); c.drawString(26,y-52,"HOJE"); c.drawRightString(W-26,y-52,"META")
    c.drawCentredString(W/2,y-52,meses(peso,po)); y-=72
    rr(c,16,y-36,W-32,36,6,fill=SURFACE,stroke=BORDER)
    c.setFillColor(MID); c.setFont("Helvetica",8); c.drawString(26,y-14,"Comprometimento declarado")
    pct_c=int(comp)/10 if comp and comp.isdigit() else 0
    bw2=W-80; rr(c,40,y-28,bw2,8,4,fill=BORDER); rr(c,40,y-28,bw2*pct_c,8,4,fill=ACCENT if pct_c>=0.7 else ORANGE)
    c.setFillColor(ACCENT if pct_c>=0.7 else ORANGE); c.setFont("Helvetica-Bold",9); c.drawRightString(W-26,y-14,f"{comp}/10"); y-=46
    c.setStrokeColor(BORDER); c.setLineWidth(0.3); c.line(16,y,W-16,y); y-=14
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",8); c.drawString(16,y,"ATIVIDADE FÍSICA"); y-=14
    for lbl,val in [("Frequência de treino",ex),("Duração do treino",tt),("Tipo de cardio",card or "Não informado"),("Duração do cardio",tc)]:
        rr(c,16,y-26,W-32,26,4,fill=SURFACE,stroke=BORDER)
        c.setFillColor(MID); c.setFont("Helvetica",8.5); c.drawString(26,y-16,lbl)
        c.setFillColor(DARK); c.setFont("Helvetica-Bold",8.5); tv=val[:36]+"..." if len(val)>38 else val; c.drawRightString(W-26,y-16,tv); y-=32
    c.setStrokeColor(BORDER); c.setLineWidth(0.3); c.line(16,y,W-16,y); y-=14
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",8); c.drawString(16,y,"OUTROS DADOS"); y-=14
    for lbl,val in [("Alimentação atual",alim),("Partes que incomodam",partes or "—"),("Limitação física",lim or "Nenhuma"),("Medicamentos",med or "Nenhum")]:
        rr(c,16,y-26,W-32,26,4,fill=SURFACE,stroke=BORDER)
        c.setFillColor(MID); c.setFont("Helvetica",8.5); c.drawString(26,y-16,lbl)
        c.setFillColor(DARK); c.setFont("Helvetica-Bold",8.5); tv=val[:34]+"..." if len(val)>36 else val; c.drawRightString(W-26,y-16,tv); y-=32
    ftr(c)

# PG4 ANALISE
def analise(c,d):
    dbg(c); hdr(c,3)
    obj=d.get('objetivo','').lower(); comp=d.get('compro',''); lim=d.get('limitacao','nenhuma')
    alim=d.get('alimentacao','').lower(); obs=d.get('obstaculo','').lower(); est=d.get('estresse','')
    y=H-50; y=badge(c,y,"SEÇÃO 3  ·  LEITURA DO SEU PERFIL"); y=title(c,y,"O que seus dados revelam"); y=sub(c,y,"Análise personalizada baseada em todas as suas respostas"); y-=8
    def obs_txt(o):
        m={'tempo':'falta de tempo','motivacao':'falta de motivação','orientacao':'não saber por onde começar','alimentacao':'dificuldade com alimentação','dinheiro':'investimento','saude':'questões de saúde'}
        return ', '.join([m.get(x.strip(),x.strip()) for x in o.split(',') if x.strip()])
    if any(x in obj for x in ['emagre','perder']): foco="Emagrecimento com déficit calórico controlado e estratégia progressiva."
    elif any(x in obj for x in ['massa','ganhar']): foco="Ganho de massa com superávit calórico e foco em treino de força."
    elif 'parto' in obj: foco="Recuperação pós-parto com reabilitação progressiva e bem-estar."
    else: foco=f"{obj.capitalize()} com protocolo adaptado ao seu perfil e rotina."
    ci=int(comp) if comp and comp.isdigit() else 0
    comp_t=f"Comprometimento {comp}/10 — você tem o mindset certo para transformar." if ci>=8 else f"Comprometimento {comp}/10. Com estratégia certa, os resultados virão."
    ei=int(est) if est and est.isdigit() else 0
    est_t=f"Estresse {est}/10 é alto e pode impactar resultados. O protocolo considera isso." if ei>=7 else f"Estresse {est}/10 está controlado — ótimo para evolução consistente."
    alim_t="A alimentação precisa de ajuste. Melhorar a nutrição acelera resultados em até 2x." if any(x in alim for x in ['irregular','melhorar','ruim']) else "Razoável. Pequenos ajustes farão grande diferença nos resultados." if 'razo' in alim else "Boa alimentação é sua aliada. Vamos potencializar isso."
    obs_r=f"Seu principal obstáculo é {obs_txt(obs)}. O protocolo foi pensado para superar isso." if obs else "O protocolo vai te guiar passo a passo para superar os obstáculos."
    lim_t=f"Limitação em {lim} será respeitada. Protocolo se adapta para você evoluir com segurança." if lim and 'nenhuma' not in lim.lower() and lim.strip() else "Sem limitações físicas — ponto de partida excelente para um protocolo completo."
    insights=[("FOCO PRINCIPAL",ACCENT,foco),("COMPROMETIMENTO",ACCENT2 if ci>=8 else ORANGE,comp_t),("ESTRESSE E SAÚDE",RED_EL if ei>=7 else ACCENT2,est_t),("ALIMENTAÇÃO",ORANGE if 'irregular' in alim or 'melhorar' in alim else ACCENT2,alim_t),("SEU OBSTÁCULO",ACCENT,obs_r),("LIMITAÇÃO FÍSICA",MUTED,lim_t)]
    for titulo,cor,texto in insights:
        lines=wrap(c,texto,"Helvetica",8.5,W-72); bh=max(48,22+len(lines)*12)
        rr(c,16,y-bh,W-32,bh,5,fill=SURFACE,stroke=BORDER)
        c.setFillColor(cor); c.rect(16,y-bh,3,bh,fill=1,stroke=0)
        c.setFont("Helvetica-Bold",7.5); c.drawString(26,y-13,titulo)
        c.setFillColor(DARK); c.setFont("Helvetica",8.5)
        for i,ln in enumerate(lines[:3]): c.drawString(26,y-26-(i*12),ln)
        y-=bh+8
    ftr(c)

# PG5 OFERTA
def oferta(c,d):
    dbg(c); hdr(c,4)
    nome=d.get('nome','').capitalize() or 'Você'; po=d.get('peso_obj',''); lim=d.get('limitacao','')
    y=H-50
    c.setFillColor(ACCENT); c.setFont("Helvetica-Bold",10); c.drawCentredString(W/2,y,"✦  PRÓXIMO PASSO"); y-=20
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",19); c.drawCentredString(W/2,y,f"{nome}, você está pronto"); y-=22
    c.drawCentredString(W/2,y,f"para chegar aos {po}kg." if po else "para transformar seu corpo."); y-=16
    c.setFillColor(MID); c.setFont("Helvetica",9); c.drawCentredString(W/2,y,"Escolha seu protocolo e comece ainda esta semana."); y-=22
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",8); c.drawString(16,y,"TUDO QUE VOCÊ RECEBE:"); y-=14
    for item in ["Treino 100% personalizado no app MFIT Personal","Vídeos explicativos gravados pelo Luis","Suporte direto via WhatsApp","Protocolo adaptado ao seu objetivo e limitações","Acompanhamento e evolução a cada etapa"]:
        c.setFillColor(ACCENT); c.setFont("Helvetica-Bold",9); c.drawString(20,y,"▸")
        c.setFillColor(DARK); c.setFont("Helvetica",9); c.drawString(32,y,item); y-=14
    y-=6; c.setStrokeColor(BORDER); c.setLineWidth(0.3); c.line(16,y,W-16,y); y-=12
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",8); c.drawString(16,y,"PLANOS INDIVIDUAIS"); y-=12
    pw=(W-40)/2; ph=96
    for i,(dest,titulo,dur,preco,sub_txt,lk) in enumerate([(False,"1 PROTOCOLO","60 dias","R$ 119","Ideal para começar",119),(True,"3 PROTOCOLOS ⭐","180 dias","R$ 297","ou 3x de R$ 99  ·  Maior transformação",297)]):
        px=16+(pw+8)*i; cor_b=ACCENT if dest else BORDER
        rr(c,px,y-ph,pw,ph,8,fill=SURFACE,stroke=cor_b,lw=1.5 if dest else 0.5)
        rr(c,px,y-ph+ph-3,pw,3,1,fill=ACCENT if dest else MUTED)
        c.setFillColor(ACCENT if dest else MUTED); c.setFont("Helvetica-Bold",7); c.drawCentredString(px+pw/2,y-16,titulo)
        c.setFillColor(MID); c.setFont("Helvetica",7.5); c.drawCentredString(px+pw/2,y-28,dur)
        c.setFillColor(ACCENT if dest else DARK); c.setFont("Helvetica-Bold",18); c.drawCentredString(px+pw/2,y-48,preco)
        c.setFillColor(MUTED); c.setFont("Helvetica",6.5)
        for j,ln in enumerate(sub_txt.split('·')): c.drawCentredString(px+pw/2,y-60-(j*9),ln.strip())
        # Botão clicável
        btn_y = y-ph+10; btn_h=18; btn_x=px+8; btn_w=pw-16
        rr(c,btn_x,btn_y,btn_w,btn_h,9,fill=ACCENT if dest else ACCENT2)
        c.setFillColor(WHITE); c.setFont("Helvetica-Bold",7.5)
        c.drawCentredString(px+pw/2,btn_y+5,"Quero este plano  →")
        c.linkURL(LINKS[lk],(px,y-ph,px+pw,y),relative=0)
    y-=ph+8
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",8); c.drawString(16,y,"PLANOS DUPLA  —  Treine com alguém da família"); y-=12
    for titulo,dur,preco,sub_txt,lk in [("DUPLA 1 PROTOCOLO","60 dias","R$ 207","Vídeos individuais para cada um",207),("DUPLA 3 PROTOCOLOS ⭐","180 dias","R$ 479","6 meses · Melhor custo-benefício",479)]:
        rr(c,16,y-50,W-32,50,6,fill=SURFACE,stroke=BORDER)
        c.setFillColor(ACCENT2); c.setFont("Helvetica-Bold",8); c.drawString(26,y-13,titulo)
        c.setFillColor(MID); c.setFont("Helvetica",7.5); c.drawString(26,y-25,f"{dur}  ·  {sub_txt}")
        c.setFillColor(ACCENT); c.setFont("Helvetica-Bold",14); c.drawRightString(W-26,y-20,preco)
        # Botão
        rr(c,W-110,y-42,94,16,8,fill=ACCENT2)
        c.setFillColor(WHITE); c.setFont("Helvetica-Bold",7)
        c.drawCentredString(W-63,y-34,"Quero este plano  →")
        c.linkURL(LINKS[lk],(16,y-50,W-16,y),relative=0); y-=56
    ftr(c)

# PG6 DEPOIMENTOS
def depoimentos(c,d):
    dbg(c); hdr(c,5)
    nome=d.get('nome','').capitalize() or 'Você'
    y=H-50; y=badge(c,y,"RESULTADOS  ·  QUEM JÁ TRANSFORMOU")
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",17); c.drawCentredString(W/2,y,f"{nome}, você não está sozinha."); y-=20
    c.setFillColor(MID); c.setFont("Helvetica",9); c.drawCentredString(W/2,y,"+350 pessoas já transformaram com o Luis Kummer."); y-=22
    rr(c,16,y-90,W-32,90,8,fill=SURFACE,stroke=BORDER); rr(c,16,y-90+87,W-32,3,1,fill=GOLD)
    c.setFillColor(GOLD); c.setFont("Helvetica-Bold",24); c.drawString(24,y-22,"\u201c")
    c.setFillColor(DARK); c.setFont("Helvetica",9)
    dep1="Segui o protocolo do Luis e perdi 9 kg em 3 meses. O treino era adaptado para minha coluna e funcionou de verdade. Nunca pensei que seria tão prático."
    lines1=wrap(c,dep1,"Helvetica",9,W-68)
    for i,ln in enumerate(lines1[:4]): c.drawString(26,y-32-(i*12),ln)
    c.setFillColor(ACCENT2); c.setFont("Helvetica-Bold",8); c.drawString(26,y-82,"Juliana M.  ·  São Paulo")
    c.setFillColor(HexColor('#FFD700')); c.drawRightString(W-26,y-82,"★★★★★"); y-=100
    dw=(W-40)/2
    for i,(stars,txt,autor) in enumerate([("★★★★★","Perdi 12 kg sem parar de comer o que gosto. Protocolo fácil de seguir.","Carla S.  ·  Curitiba"),("★★★★★","Treino adaptado pro joelho. Resultado em 60 dias. Recomendo!","Marcos R.  ·  BH")]):
        dx=16+(dw+8)*i; rr(c,dx,y-82,dw,82,8,fill=SURFACE,stroke=BORDER)
        c.setFillColor(HexColor('#FFD700')); c.setFont("Helvetica-Bold",9); c.drawCentredString(dx+dw/2,y-14,stars)
        c.setFillColor(DARK); c.setFont("Helvetica",8)
        lines2=wrap(c,txt,"Helvetica",8,dw-20)
        for j,ln in enumerate(lines2[:3]): c.drawCentredString(dx+dw/2,y-28-(j*12),ln)
        c.setFillColor(ACCENT2); c.setFont("Helvetica-Bold",7); c.drawCentredString(dx+dw/2,y-72,autor)
    y-=92
    c.setStrokeColor(BORDER); c.setLineWidth(0.3); c.line(16,y,W-16,y); y-=14
    c.setFillColor(DARK); c.setFont("Helvetica-Bold",17); c.drawCentredString(W/2,y,f"{nome}, agora é a sua vez."); y-=20
    c.setFillColor(ACCENT2); c.setFont("Helvetica",9); c.drawCentredString(W/2,y,"Escolha seu protocolo e comece hoje mesmo.")
    ftr(c)

def gerar_pdf(dados, output_path="/mnt/user-data/outputs/diagnostico_luis_kummer.pdf"):
    cv=canvas.Canvas(output_path,pagesize=(W,H))
    cv.setTitle(f"Diagnóstico Personalizado - {dados.get('nome','').capitalize()}")
    capa(cv,dados); cv.showPage()
    biometrico(cv,dados); cv.showPage()
    meta(cv,dados); cv.showPage()
    analise(cv,dados); cv.showPage()
    oferta(cv,dados); cv.showPage()
    depoimentos(cv,dados)
    cv.save(); return output_path

if __name__=="__main__":
    dados_teste={"nome":"Camila","data":"14/05/2026","objetivo":"emagrecer e perder gordura","sexo":"F","corpo_atual":"moderada","corpo_obj":"fitness","partes":"barriga, coxas","bemestar":"4","peso":"82","altura":"165","idade":"34","peso_obj":"68","imc":"30.1","limitacao":"joelho/tornozelo","medicamentos":"nenhum","exercicio":"treina 1-2x/semana","tempo_treino":"30 a 45 min","cardio":"caminhada","tempo_cardio":"20 a 30 min","alimentacao":"precisa melhorar a alimentação","obstaculo":"tempo, motivacao","estresse":"7","compro":"9","origem":"Instagram"}
    print(gerar_pdf(dados_teste))
