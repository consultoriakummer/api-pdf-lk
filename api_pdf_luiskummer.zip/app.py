from flask import Flask, request, send_file, jsonify
import tempfile, os
from gerar_pdf import gerar_pdf

app = Flask(__name__)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "ok"})

@app.route('/gerar-diagnostico', methods=['POST'])
def gerar_diagnostico():
    try:
        dados = request.get_json()
        if not dados:
            return jsonify({"erro": "Dados não recebidos"}), 400

        # Gerar PDF em arquivo temporário
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp:
            tmp_path = tmp.name

        gerar_pdf(dados, tmp_path)

        nome = dados.get('nome', 'diagnostico').lower().replace(' ', '_')
        filename = f"diagnostico_{nome}.pdf"

        return send_file(
            tmp_path,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=filename
        )

    except Exception as e:
        return jsonify({"erro": str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
